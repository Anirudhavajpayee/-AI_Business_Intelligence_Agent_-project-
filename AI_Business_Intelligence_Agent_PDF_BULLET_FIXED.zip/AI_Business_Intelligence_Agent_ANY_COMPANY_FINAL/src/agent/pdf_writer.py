from __future__ import annotations

from pathlib import Path
from typing import Iterable, List

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import ListFlowable, ListItem, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .models import IntelligenceReport
from .utils import ascii_text


class SimplePDFWriter:
    def __init__(self) -> None:
        self.styles = getSampleStyleSheet()
        self.styles.add(ParagraphStyle(name="Small", parent=self.styles["BodyText"], fontName="Helvetica", fontSize=8.5, leading=11, alignment=TA_LEFT))
        self.styles.add(ParagraphStyle(name="Section", parent=self.styles["Heading2"], fontName="Helvetica-Bold", fontSize=13, leading=16, spaceBefore=10, spaceAfter=6))
        self.styles.add(ParagraphStyle(name="Sub", parent=self.styles["Heading3"], fontName="Helvetica-Bold", fontSize=10.5, leading=13, spaceBefore=6, spaceAfter=4))

    def write(self, report: IntelligenceReport, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        doc = SimpleDocTemplate(str(path), pagesize=A4, rightMargin=1.3 * cm, leftMargin=1.3 * cm, topMargin=1.2 * cm, bottomMargin=1.2 * cm)
        story: List = []
        story.append(Paragraph(ascii_text("AI-Powered Business & Market Intelligence Report"), self.styles["Title"]))
        story.append(Paragraph(ascii_text(f"Company: {report.company}"), self.styles["Heading2"]))
        story.append(Paragraph(ascii_text(f"Generated: {report.generated_at}"), self.styles["Small"]))
        story.append(Spacer(1, 8))

        overview_rows = [
            ["Domain", report.domain or "Not provided"],
            ["Report Focus", report.service_line],
            ["Detected Industry", report.industry],
            ["Confidence Score", f"{report.confidence_score}/100"],
            ["LLM Used", "Yes" if report.llm_used else "No"],
            ["Live Search Used", "Yes" if report.live_search_used else "No"],
        ]
        story.append(self._table(overview_rows, [4.2 * cm, 13.2 * cm]))
        story.append(Spacer(1, 8))

        self._section(story, "Executive Summary", report.overview)
        self._section(story, "Detected Services", report.detected_services)
        self._section(story, "Target Customers / Users", report.target_customers)
        self._section(story, "Market Positioning", report.positioning)
        self._section(story, "Activity Signals", report.activity_signals)
        self._section(story, "ERP Opportunity Report", report.erp_report)
        self._section(story, "CRM Opportunity Report", report.crm_report)
        self._section(story, "Recommended ERP Modules", report.erp_modules)
        self._section(story, "Recommended CRM Modules", report.crm_modules)
        self._section(story, "Implementation Roadmap", report.implementation_roadmap)

        story.append(Paragraph("Competitor Intelligence", self.styles["Section"]))
        comp_rows = [["Competitor", "Fit", "Focus", "Suggested Action"]]
        for c in report.competitors:
            comp_rows.append([c.name, str(c.fit_score), c.focus, c.suggested_action])
        story.append(self._table(comp_rows, [3.7 * cm, 1.2 * cm, 5.8 * cm, 6.7 * cm], header=True))

        story.append(PageBreak())
        story.append(Paragraph("SWOT Analysis", self.styles["Section"]))
        for key, values in report.swot.items():
            story.append(Paragraph(ascii_text(key), self.styles["Sub"]))
            story.append(self._bullets(values))

        story.append(Paragraph("PESTLE Analysis", self.styles["Section"]))
        pestle_rows = [[k, v] for k, v in report.pestle.items()]
        story.append(self._table(pestle_rows, [3.5 * cm, 13.9 * cm]))

        self._section(story, "Market Gaps", report.market_gaps)
        self._section(story, "Lead Opportunities", report.lead_opportunities)
        self._section(story, "Outreach Email", report.outreach_email)
        self._section(story, "Call Script", report.call_script)
        self._section(story, "Recommendations", report.recommendations)
        self._section(story, "Important Notes", report.notes)

        story.append(Paragraph("Source Status", self.styles["Section"]))
        src_rows = [["Source", "Type", "Status", "Score", "URL/Note"]]
        for s in report.sources[:12]:
            src_rows.append([s.title[:60], s.source_type, s.status, str(s.quality_score), (s.url or s.note)[:120]])
        story.append(self._table(src_rows, [4.3 * cm, 2.3 * cm, 2.0 * cm, 1.4 * cm, 7.4 * cm], header=True))

        doc.build(story)
        return path

    def _section(self, story: List, title: str, content) -> None:
        story.append(Paragraph(ascii_text(title), self.styles["Section"]))
        if isinstance(content, list):
            story.append(self._bullets(content))
        else:
            for para in str(content).split("\n"):
                if para.strip():
                    story.append(Paragraph(ascii_text(para.strip()), self.styles["BodyText"]))

    def _bullets(self, values: Iterable[str]) -> ListFlowable:
        """Create a ReportLab bullet list safely across ReportLab versions.

        Do not pass start="circle" with bulletType="bullet". Some ReportLab
        versions treat start as a numeric counter and raise an error.
        """
        if values is None:
            values = []

        items = []
        for value in values:
            text = ascii_text(str(value).strip())
            if text:
                items.append(
                    ListItem(
                        Paragraph(text, self.styles["BodyText"]),
                        bulletColor=colors.black,
                    )
                )

        if not items:
            items.append(ListItem(Paragraph("Not available", self.styles["BodyText"])))

        return ListFlowable(
            items,
            bulletType="bullet",
            leftIndent=16,
            bulletIndent=6,
        )

    def _table(self, rows: List[List[str]], widths: List[float], header: bool = False) -> Table:
        data = [[Paragraph(ascii_text(str(cell)), self.styles["Small"]) for cell in row] for row in rows]
        table = Table(data, colWidths=widths, repeatRows=1 if header else 0)
        style = [
            ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]
        if header:
            style.extend([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#EAF2FF")), ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold")])
        else:
            style.append(("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#F2F2F2")))
        table.setStyle(TableStyle(style))
        return table
