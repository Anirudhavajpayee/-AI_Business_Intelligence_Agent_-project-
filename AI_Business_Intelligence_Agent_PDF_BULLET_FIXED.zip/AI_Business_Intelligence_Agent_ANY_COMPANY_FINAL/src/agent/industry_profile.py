from __future__ import annotations

import re
from typing import Dict, List, Tuple

from .utils import normalize_domain


class IndustryDetector:
    """Weighted detector used only for fallback mode.

    For real accuracy use Search API + OpenAI LLM. This detector avoids the old bug where
    generic words like training could classify Maruti Suzuki as Education.
    """

    def detect(self, company: str, domain: str, service_line: str = "", evidence_text: str = "") -> Tuple[str, int]:
        domain = normalize_domain(domain)
        primary = self._norm(f"{company} {domain}")
        focus = self._norm(service_line)
        evidence = self._norm(evidence_text)

        # Brand/domain signals get highest priority. This is not hardcoded reporting;
        # it is a guard against false classification in offline fallback mode.
        brand_rules = [
            ("Networking, Cybersecurity and Enterprise Technology", [
                "cisco", "cisco systems", "cisco systems india", "cisco india", "webex",
                "cisco networking", "cisco security", "catalyst", "meraki", "duo security",
                "splunk", "nexus", "firepower", "umbrella", "thousandeyes"
            ]),
            # IT companies are checked before automotive because names like "Tech Mahindra"
            # contain Mahindra but belong to IT Services, not Automobile.
            ("IT Services and Consulting", [
                "tcs", "tata consultancy", "infosys", "wipro", "hcltech", "hcl tech",
                "cognizant", "accenture", "tech mahindra", "lti mindtree", "ltimindtree",
                "mphasis", "persistent", "persistent systems", "coforge", "hexaware",
                "birlasoft", "capgemini", "ibm", "oracle", "sap", "salesforce",
                "microsoft", "adobe", "servicenow"
            ]),
            ("Automobile / Automotive", [
                "maruti", "suzuki", "marutisuzuki", "nexa", "arena", "hyundai",
                "tata motors", "mahindra & mahindra", "mahindra auto", "mahindra automotive",
                "toyota", "honda cars", "kia", "skoda", "volkswagen"
            ]),
            ("Professional Services / Consulting", ["pwc", "pricewaterhousecoopers", "deloitte", "kpmg", "ey", "ernst young", "grant thornton", "bdo"]),
            ("Banking and Financial Services", ["hdfc", "icici", "axis bank", "kotak", "sbi", "state bank", "indusind", "bank"]),
            ("Healthcare / Hospitals", ["apollo hospital", "fortis", "max healthcare", "medanta", "manipal", "narayana health", "hospital", "clinic"]),
            ("Retail and Ecommerce", ["reliance retail", "dmart", "avenue supermarts", "trent", "flipkart", "amazon", "myntra"]),
            ("Paints / Home Decor", ["asian paints", "berger paints", "nerolac", "akzonobel", "indigo paints", "jsw paints"]),
            ("FMCG / Consumer Goods", ["rspl", "ghadi", "rohit surfactants", "hul", "hindustan unilever", "nirma", "procter", "jyothy"]),
            ("Fertilizer / Agriculture Cooperative", ["iffco", "indian farmers fertiliser", "indian farmers fertilizer", "kribhco", "krishak bharati", "fertiliser cooperative", "fertilizer cooperative", "agro fertilizer", "agri inputs"]),
            ("Building Materials / Cement", ["ultratech", "ultratech cement", "ambuja cement", "acc cement", "shree cement", "dalmia bharat", "jk cement", "jsw cement", "cement"]),
            ("Food Delivery / Restaurant Tech", ["zomato", "swiggy", "eatsure", "magicpin", "ondc food"]),
            ("Engineering / Construction / EPC", ["larsen", "toubro", "larsentoubro", "lt", "l&t", "tata projects", "afcons", "shapoorji", "kalpataru", "infra", "infrastructure", "construction"]),
        ]
        for industry, terms in brand_rules:
            if self._has(primary, terms):
                return industry, 92

        keyword_rules: Dict[str, Dict[str, List[str]]] = {
            "FMCG / Consumer Goods": {
                "strong": ["fmcg", "consumer goods", "fast moving consumer goods", "biscuit", "bakery", "food products", "dairy", "personal care", "home care", "household products", "detergent", "soap", "packaged food"],
                "weak": ["distribution", "dealer", "retail", "brand", "supply chain", "inventory", "consumer support", "warehouse", "sales"],
            },
            "Automobile / Automotive": {
                "strong": ["automobile", "automotive", "vehicle", "car", "dealer", "dealership", "showroom", "spare parts", "warranty", "service center", "test drive"],
                "weak": ["booking", "fleet", "workshop", "accessories", "after sales"],
            },
            "Professional Services / Consulting": {
                "strong": ["audit", "tax", "assurance", "advisory", "consulting", "risk consulting", "management consulting"],
                "weak": ["compliance", "governance", "finance transformation"],
            },
            "Banking and Financial Services": {
                "strong": ["bank", "banking", "loan", "credit card", "deposit", "financial services", "insurance"],
                "weak": ["branch", "kyc", "risk", "customer account"],
            },
            "Networking, Cybersecurity and Enterprise Technology": {
                "strong": ["networking", "secure networking", "cybersecurity", "network security", "router", "switch", "wireless", "firewall", "collaboration", "webex", "data center", "observability", "zero trust", "sd wan", "meraki", "catalyst", "nexus", "duo", "umbrella", "thousandeyes", "splunk"],
                "weak": ["infrastructure", "cloud", "ai infrastructure", "partner", "channel", "license", "support", "security"],
            },
            "IT Services and Consulting": {
                "strong": ["it services", "software services", "cloud", "digital transformation", "enterprise application", "managed services"],
                "weak": ["technology", "analytics", "outsourcing", "data"],
            },
            "Healthcare / Hospitals": {
                "strong": ["hospital", "healthcare", "clinic", "patient", "medical", "diagnostic"],
                "weak": ["doctor", "appointment", "pharmacy", "consultation"],
            },
            "Education and Training": {
                "strong": ["school", "college", "university", "student", "admission", "academy", "institute"],
                "weak": ["education", "course", "batch", "fee collection", "counseling", "training"],
            },
            "Engineering / Construction / EPC": {
                "strong": ["construction", "infrastructure", "epc", "civil", "builder", "contractor", "real estate", "engineering projects"],
                "weak": ["site", "boq", "tender", "material", "project execution"],
            },
            "Retail and Ecommerce": {
                "strong": ["retail", "store", "supermarket", "ecommerce", "omnichannel", "wholesale", "trading"],
                "weak": ["pos", "inventory", "loyalty", "supply chain"],
            },
            "Fertilizer / Agriculture Cooperative": {
                "strong": ["fertilizer", "fertiliser", "agriculture", "agri", "agro", "farmer", "cooperative", "urea", "dap", "npk", "nano urea", "bio fertilizer", "crop nutrient"],
                "weak": ["dealer", "distribution", "warehouse", "plant", "production", "subsidy", "soil", "seed", "rural", "supply chain"],
            },
            "Building Materials / Cement": {
                "strong": ["cement", "ready mix concrete", "rmc", "building materials", "construction material", "white cement", "concrete", "clinker", "grinding unit", "bulk cement"],
                "weak": ["dealer", "distribution", "logistics", "project sales", "plant", "manufacturing", "bagging", "dispatch", "warehouse", "retail counter"],
            },
            "Manufacturing / Industrial": {
                "strong": ["manufacturing", "factory", "plant", "production", "industrial", "machine"],
                "weak": ["quality", "dispatch", "raw material", "work order", "vendor"],
            },
            "Hospitality / Restaurant": {
                "strong": ["hotel", "restaurant", "cafe", "resort", "hospitality", "banquet", "catering"],
                "weak": ["reservation", "guest", "table ordering", "food"],
            },
            "Water Treatment / Services": {
                "strong": ["water treatment", "ro plant", "stp", "wtp", "etp", "fountain", "filtration"],
                "weak": ["purification", "aqua", "maintenance", "amc"],
            },
            "Software / SaaS": {
                "strong": ["software", "saas", "app development", "web development", "business automation"],
                "weak": ["dashboard", "integration", "api", "workflow"],
            },
        }

        scores: Dict[str, int] = {}
        strong_hits: Dict[str, int] = {}
        for industry, cfg in keyword_rules.items():
            score = 0
            hits = 0
            for word in cfg["strong"]:
                if self._has(primary, [word]):
                    score += 20
                    hits += 1
                if self._has(evidence, [word]):
                    score += 8
                    hits += 1
                if self._has(focus, [word]):
                    score += 4
                    hits += 1
            for word in cfg["weak"]:
                if self._has(primary, [word]):
                    score += 10
                if self._has(evidence, [word]):
                    score += 3
                if self._has(focus, [word]):
                    score += 2
            # Guardrail: weak words such as dealer/support/training must not decide an industry alone.
            if hits == 0 and score < 18:
                score = 0
            scores[industry] = score
            strong_hits[industry] = hits

        # Education guard: it needs primary company/domain/evidence to strongly suggest education.
        if scores.get("Education and Training", 0) > 0:
            if not self._has(primary + " " + evidence, ["school", "college", "university", "student", "admission", "academy", "institute"]):
                scores["Education and Training"] = min(scores["Education and Training"], 5)

        industry, score = max(scores.items(), key=lambda item: item[1])
        if score <= 6:
            return "Not verified from collected public evidence", 35
        return industry, min(90, score)

    def default_competitors(self, industry: str) -> List[str]:
        data = {
            "Automobile / Automotive": ["Hyundai Motor India", "Tata Motors", "Mahindra & Mahindra", "Honda Cars India", "Toyota Kirloskar Motor"],
            "Professional Services / Consulting": ["Deloitte", "KPMG", "EY", "Grant Thornton", "BDO"],
            "Banking and Financial Services": ["ICICI Bank", "Axis Bank", "Kotak Mahindra Bank", "State Bank of India", "IndusInd Bank"],
            "Networking, Cybersecurity and Enterprise Technology": ["Juniper Networks", "HPE Aruba Networking", "Fortinet", "Palo Alto Networks", "Check Point"],
            "IT Services and Consulting": ["Infosys", "Wipro", "HCLTech", "Accenture", "Cognizant"],
            "Healthcare / Hospitals": ["Fortis Healthcare", "Max Healthcare", "Medanta", "Manipal Hospitals", "Narayana Health"],
            "Education and Training": ["CollegeDekho", "Shiksha", "Unacademy", "BYJU'S", "Vedantu"],
            "Engineering / Construction / EPC": ["Tata Projects", "Shapoorji Pallonji", "Afcons Infrastructure", "KEC International", "Kalpataru Projects"],
            "Retail and Ecommerce": ["DMart", "Trent", "Amazon India", "Flipkart", "Avenue Supermarts"],
            "Paints / Home Decor": ["Berger Paints", "Kansai Nerolac", "AkzoNobel India", "Indigo Paints", "JSW Paints"],
            "FMCG / Consumer Goods": ["HUL", "P&G India", "Nirma", "Jyothy Labs", "Wipro Consumer Care"],
            "Fertilizer / Agriculture Cooperative": ["IFFCO", "KRIBHCO", "National Fertilizers Limited", "Rashtriya Chemicals and Fertilizers", "Coromandel International", "Chambal Fertilisers"],
            "Building Materials / Cement": ["Ambuja Cements", "ACC", "Shree Cement", "Dalmia Bharat", "JK Cement", "JSW Cement"],
            "Food Delivery / Restaurant Tech": ["Swiggy", "EatSure", "Domino's India", "Magicpin", "ONDC Food"],
        }
        return data.get(industry, ["Industry competitor 1", "Industry competitor 2", "Regional competitor", "Digital solution provider", "Market leader"])

    def erp_modules(self, industry: str) -> List[str]:
        common = ["Finance & Accounting", "Management Dashboard", "Approval Workflow", "Document Management"]
        special = {
            "Automobile / Automotive": ["Dealer Management", "Vehicle Inventory", "Spare Parts Inventory", "Service Job Card", "Warranty Claims", "Workshop Operations"],
            "Professional Services / Consulting": ["Project Billing", "Resource Allocation", "Timesheet Management", "Compliance Tracking", "Engagement Profitability"],
            "Banking and Financial Services": ["Customer Account Operations", "Loan Processing", "KYC/Compliance", "Risk Controls", "Branch Operations"],
            "Networking, Cybersecurity and Enterprise Technology": ["Partner/Channel Sales Operations", "Subscription and Licensing", "Hardware Inventory and Serial Tracking", "Support SLA", "RMA/Warranty Workflow", "Product Lifecycle Management", "Service Contract Management"],
            "IT Services and Consulting": ["Project Management", "Resource Planning", "Support SLA", "Subscription/AMC Billing", "Delivery Governance"],
            "Fertilizer / Agriculture Cooperative": ["Plant Production Planning", "Raw Material Procurement", "Fertilizer Batch/Quality Control", "Warehouse and Bagging Operations", "Dealer/Distributor Management", "Subsidy and Compliance Tracking", "Farmer Service Operations"],
            "Building Materials / Cement": ["Plant Production Planning", "Clinker/Cement Quality Control", "Dealer and Project Sales Management", "Warehouse and Dispatch", "Fleet/Logistics Tracking", "Credit Control", "Construction Site Demand Forecasting"],
            "Healthcare / Hospitals": ["Patient Registration", "OPD/IPD Billing", "Pharmacy Inventory", "Appointment Scheduling", "Lab/Diagnostic Workflow"],
            "Education and Training": ["Admission Management", "Fee Collection", "Attendance", "Timetable", "Examination", "Certificate Management"],
            "Engineering / Construction / EPC": ["Project Planning", "BOQ & Estimation", "Procurement", "Site Inventory", "Subcontractor Billing", "Progress Billing"],
            "Retail and Ecommerce": ["POS", "Inventory", "Warehouse", "Purchase", "Omnichannel Orders", "Loyalty Billing"],
            "Food Delivery / Restaurant Tech": ["Restaurant Partner Master", "Order Management", "Delivery Partner Operations", "Commission & Settlement", "Refund/Reconciliation", "Hyperlocal Operations", "Partner Payouts"],
            "Hospitality / Restaurant": ["Table Reservation", "Kitchen Order Ticket", "Menu/Recipe Management", "Inventory", "Billing", "Guest Management"],
            "Manufacturing / Industrial": ["Production Planning", "BOM", "Raw Material Inventory", "Quality Control", "Dispatch", "Vendor Management"],
        }
        return special.get(industry, ["Sales Order", "Purchase", "Inventory", "Billing", "Customer/Vendor Master"]) + common

    def crm_modules(self, industry: str) -> List[str]:
        common = ["Lead Management", "Opportunity Pipeline", "Follow-up Reminder", "Customer Communication History", "Support Ticketing"]
        special = {
            "Automobile / Automotive": ["Car Inquiry", "Test Drive", "Quotation", "Booking", "Delivery Update", "Service Reminder"],
            "Professional Services / Consulting": ["Enterprise Account Management", "Proposal Tracking", "Partner Review Dashboard", "Client Meeting Notes"],
            "Banking and Financial Services": ["Customer 360", "Loan Lead Tracking", "Cross-sell Campaigns", "Complaint Management"],
            "Networking, Cybersecurity and Enterprise Technology": ["Enterprise Account Management", "Partner/Channel CRM", "Deal Registration", "Demo/POC Tracking", "Customer Success", "Renewal Pipeline", "Support Case Management"],
            "IT Services and Consulting": ["Demo Tracking", "Proposal Management", "Implementation Stage Tracking", "Renewal Pipeline"],
            "Fertilizer / Agriculture Cooperative": ["Farmer 360", "Dealer/Distributor CRM", "Agri Input Inquiry", "Field Officer Visit Tracking", "Complaint and Quality Ticketing", "Campaign and Advisory Communication", "Cooperative Member Engagement"],
            "Building Materials / Cement": ["Dealer/Retailer CRM", "Project Sales Pipeline", "Contractor/Builder Engagement", "Site Visit Tracking", "Price/Quotation Follow-up", "Complaint and Quality Ticketing", "Loyalty/Scheme Communication"],
            "Healthcare / Hospitals": ["Patient Inquiry", "Appointment Follow-up", "Health Package Campaigns", "Patient Feedback"],
            "Education and Training": ["Admission Inquiry", "Counseling Pipeline", "Student Follow-up", "Parent Communication"],
            "Engineering / Construction / EPC": ["Tender/Opportunity Tracking", "Client Account Management", "Site Visit Follow-up", "Project Proposal Pipeline"],
            "Retail and Ecommerce": ["Customer Loyalty", "Campaign Management", "Complaint Handling", "Repeat Purchase Segmentation"],
            "Food Delivery / Restaurant Tech": ["Customer App Inquiry", "Restaurant Partner CRM", "Order Issue Ticketing", "Refund Follow-up", "Delivery Feedback", "Marketing Campaigns", "Loyalty & Offers"],
            "Hospitality / Restaurant": ["Guest Inquiry", "Reservation Follow-up", "Feedback Management", "Offer Campaigns", "Repeat Visit Tracking"],
        }
        return special.get(industry, []) + common

    @staticmethod
    def _norm(value: str) -> str:
        return re.sub(r"\s+", " ", (value or "").lower()).strip()

    @staticmethod
    def _has(text: str, words: List[str]) -> bool:
        text = text or ""
        for word in words:
            w = (word or "").lower().strip()
            if not w:
                continue
            if " " in w or "." in w or "&" in w:
                if w in text:
                    return True
            else:
                if re.search(rf"(?<![a-z0-9]){re.escape(w)}(?![a-z0-9])", text):
                    return True
        return False
