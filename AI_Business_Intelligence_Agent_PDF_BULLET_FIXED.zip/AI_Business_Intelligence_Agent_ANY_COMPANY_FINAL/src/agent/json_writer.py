from __future__ import annotations

import json
from pathlib import Path

from .models import IntelligenceReport


class JSONReportWriter:
    def write(self, report: IntelligenceReport, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
        return path
