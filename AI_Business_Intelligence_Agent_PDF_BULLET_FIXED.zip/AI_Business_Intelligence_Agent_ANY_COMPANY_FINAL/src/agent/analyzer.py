from __future__ import annotations

import json
import os
import re
import urllib.request
from datetime import datetime
from typing import Any, Dict, List

from .industry_profile import IndustryDetector
from .models import CompetitorInsight, IntelligenceReport, SourceRecord
from .source_collector import SourceCollector
from .utils import clean_text, normalize_domain, split_csv, split_names_and_urls, unique_keep_order


class BusinessIntelligenceEngine:
    def __init__(self) -> None:
        self.collector = SourceCollector()
        self.detector = IndustryDetector()

    def analyze(
        self,
        company: str,
        domain: str = "",
        service_line: str = "ERP and CRM Business Process Analysis",
        manual_competitors: List[str] | None = None,
        urls: List[str] | None = None,
        top_n: int = 5,
        use_live_search: bool = False,
        search_provider: str = "serper",
        api_key: str = "",
        llm_provider: str = "none",
        llm_api_key: str = "",
        llm_model: str = "gpt-4o-mini",
    ) -> IntelligenceReport:
        company = (company or "").strip()
        if not company:
            raise ValueError("Company name is required.")
        clean_domain = normalize_domain(domain)
        service_line = (service_line or "ERP and CRM Business Process Analysis").strip()
        manual_competitors = unique_keep_order([c for c in (manual_competitors or []) if c and not re.match(r"https?://|www\.", c.strip(), re.I)])
        urls = unique_keep_order(urls or [])
        top_n = max(1, min(20, int(top_n or 5)))

        sources = self.collector.collect(
            company=company,
            domain=clean_domain,
            urls=urls,
            service_line=service_line,
            use_live_search=use_live_search,
            search_provider=search_provider,
            api_key=api_key,
            max_search_results=top_n,
        )

        actual_live_search_used = any(s.source_type == "live_search" and s.status == "available" for s in sources)

        llm_provider = (llm_provider or "none").strip().lower()
        llm_api_key = (llm_api_key or "").strip() or os.getenv("OPENAI_API_KEY", "").strip()
        llm_model = (llm_model or "gpt-4o-mini").strip() or os.getenv("OPENAI_MODEL", "gpt-4o-mini")

        if llm_provider == "openai" and llm_api_key:
            llm_json = self._try_openai_responses(company, clean_domain, service_line, manual_competitors, top_n, sources, llm_api_key, llm_model)
            if not llm_json:
                llm_json = self._try_openai_chat(company, clean_domain, service_line, manual_competitors, top_n, sources, llm_api_key, llm_model)
            if llm_json:
                return self._report_from_llm(company, clean_domain, service_line, manual_competitors, top_n, sources, llm_json, actual_live_search_used)

        return self._fallback_report(company, clean_domain, service_line, manual_competitors, top_n, sources, actual_live_search_used)

    # --------------------------- OpenAI synthesis ---------------------------
    def _prompt(self, company: str, domain: str, service_line: str, manual_competitors: List[str], top_n: int, sources: List[SourceRecord]) -> str:
        evidence = self._evidence_text(sources, 30000)
        return f"""
You are a strict business intelligence analyst for an MNC-level presentation.
Generate a factual ERP + CRM Business & Market Intelligence report for the CURRENT USER INPUT only.

CRITICAL RULES:
1. Use only the current user input and collected evidence. Never reuse sample data from another company.
2. The service line/report focus is the analysis focus. Do not claim it is the company's own service unless evidence supports it.
3. If something is not verified from evidence, write exactly: Not verified from collected public evidence.
4. Prefer official domain/user URLs over search snippets.
5. Do not classify an automobile company as education just because a page contains "training".
6. Competitors must be from user input or evidence. Do not convert URLs into competitor names.
7. Output only valid JSON. No markdown.

CURRENT USER INPUT:
Company: {company}
Domain: {domain or 'Not provided'}
Report Focus: {service_line}
Manual Competitors: {', '.join(manual_competitors) if manual_competitors else 'Not provided'}
Top N Competitors: {top_n}

COLLECTED EVIDENCE:
{evidence}

Return JSON with exactly these keys:
{{
  "industry": "...",
  "overview": "...",
  "detected_services": ["..."],
  "target_customers": ["..."],
  "positioning": "...",
  "activity_signals": ["..."],
  "erp_report": ["..."],
  "crm_report": ["..."],
  "erp_modules": ["..."],
  "crm_modules": ["..."],
  "implementation_roadmap": ["..."],
  "competitors": [{{"name":"...", "fit_score":90, "focus":"...", "strengths":["..."], "risks":["..."], "differentiation":"...", "suggested_action":"..."}}],
  "swot": {{"Strengths":["..."], "Weaknesses":["..."], "Opportunities":["..."], "Threats":["..."]}},
  "pestle": {{"Political":"...", "Economic":"...", "Social":"...", "Technological":"...", "Legal":"...", "Environmental":"..."}},
  "market_gaps": ["..."],
  "lead_opportunities": ["..."],
  "outreach_email": "...",
  "call_script": ["..."],
  "recommendations": ["..."],
  "confidence_score": 0,
  "notes": ["..."]
}}
""".strip()

    def _try_openai_responses(self, company: str, domain: str, service_line: str, manual_competitors: List[str], top_n: int, sources: List[SourceRecord], api_key: str, model: str) -> Dict[str, Any] | None:
        prompt = self._prompt(company, domain, service_line, manual_competitors, top_n, sources)
        payload = {
            "model": model,
            "input": [
                {"role": "system", "content": "Return strict JSON only. Be evidence-based and do not invent unsupported company facts."},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.1,
            "text": {"format": {"type": "json_object"}},
        }
        try:
            req = urllib.request.Request(
                "https://api.openai.com/v1/responses",
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=60) as response:
                data = json.loads(response.read().decode("utf-8", errors="ignore"))
            text = data.get("output_text") or self._extract_responses_text(data)
            return self._extract_json(text)
        except Exception as exc:
            sources.append(SourceRecord("OpenAI Responses API Error", "openai-responses-api", "llm", "error", 20, f"{type(exc).__name__}: {exc}", ""))
            return None

    def _try_openai_chat(self, company: str, domain: str, service_line: str, manual_competitors: List[str], top_n: int, sources: List[SourceRecord], api_key: str, model: str) -> Dict[str, Any] | None:
        prompt = self._prompt(company, domain, service_line, manual_competitors, top_n, sources)
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": "Return strict JSON only. Be evidence-based and do not invent unsupported company facts."},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.1,
            "response_format": {"type": "json_object"},
        }
        try:
            req = urllib.request.Request(
                "https://api.openai.com/v1/chat/completions",
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=60) as response:
                data = json.loads(response.read().decode("utf-8", errors="ignore"))
            text = data["choices"][0]["message"]["content"]
            return self._extract_json(text)
        except Exception as exc:
            sources.append(SourceRecord("OpenAI Chat API Error", "openai-chat-api", "llm", "error", 20, f"{type(exc).__name__}: {exc}", ""))
            return None

    def _extract_responses_text(self, data: Dict[str, Any]) -> str:
        parts: List[str] = []
        for item in data.get("output", []) or []:
            for c in item.get("content", []) or []:
                if isinstance(c, dict):
                    parts.append(str(c.get("text") or c.get("content") or ""))
        return "\n".join([p for p in parts if p])

    def _extract_json(self, text: str) -> Dict[str, Any] | None:
        text = (text or "").strip()
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.S | re.I).strip()
        try:
            parsed = json.loads(text)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass
        match = re.search(r"\{.*\}", text, flags=re.S)
        if match:
            try:
                parsed = json.loads(match.group(0))
                return parsed if isinstance(parsed, dict) else None
            except Exception:
                return None
        return None

    # --------------------------- Report builders ---------------------------
    def _report_from_llm(self, company: str, domain: str, service_line: str, manual_competitors: List[str], top_n: int, sources: List[SourceRecord], data: Dict[str, Any], live_search_used: bool) -> IntelligenceReport:
        industry = self._str(data.get("industry"), "Not verified from collected public evidence")
        competitors = self._competitors_from_json(data.get("competitors"), manual_competitors, industry, top_n)
        swot = data.get("swot") if isinstance(data.get("swot"), dict) else {}
        pestle = data.get("pestle") if isinstance(data.get("pestle"), dict) else {}
        confidence = self._int_between(data.get("confidence_score"), 0, 100, self._confidence(sources, llm_used=True))
        return IntelligenceReport(
            company=company,
            domain=domain,
            service_line=service_line,
            industry=industry,
            generated_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            overview=self._str(data.get("overview"), f"Business intelligence report for {company}."),
            detected_services=self._list(data.get("detected_services"), ["Not verified from collected public evidence"]),
            target_customers=self._list(data.get("target_customers"), ["Not verified from collected public evidence"]),
            positioning=self._str(data.get("positioning"), "Not verified from collected public evidence"),
            activity_signals=self._list(data.get("activity_signals"), self._activity(sources)),
            erp_report=self._list(data.get("erp_report"), self._erp_report(company, industry)),
            crm_report=self._list(data.get("crm_report"), self._crm_report(company, industry)),
            erp_modules=self._list(data.get("erp_modules"), self.detector.erp_modules(industry)),
            crm_modules=self._list(data.get("crm_modules"), self.detector.crm_modules(industry)),
            implementation_roadmap=self._list(data.get("implementation_roadmap"), self._roadmap()),
            competitors=competitors,
            swot={
                "Strengths": self._list(swot.get("Strengths"), ["Evidence-backed company data collected for analysis"]),
                "Weaknesses": self._list(swot.get("Weaknesses"), ["Some details may require official validation"]),
                "Opportunities": self._list(swot.get("Opportunities"), ["ERP and CRM process improvement opportunity"]),
                "Threats": self._list(swot.get("Threats"), ["Competitive pressure and changing customer expectations"]),
            },
            pestle={
                "Political": self._str(pestle.get("Political"), "Regulatory and policy changes may affect operations."),
                "Economic": self._str(pestle.get("Economic"), "Budget cycles and demand conditions may affect transformation decisions."),
                "Social": self._str(pestle.get("Social"), "Customer expectations for transparent and faster service are increasing."),
                "Technological": self._str(pestle.get("Technological"), "Cloud ERP, CRM, analytics and automation can improve efficiency."),
                "Legal": self._str(pestle.get("Legal"), "Data privacy, contract and compliance workflows should be controlled."),
                "Environmental": self._str(pestle.get("Environmental"), "Digital workflows can reduce paper and improve reporting transparency."),
            },
            market_gaps=self._list(data.get("market_gaps"), self._market_gaps(company, industry)),
            lead_opportunities=self._list(data.get("lead_opportunities"), self._lead_opportunities(company, industry)),
            outreach_email=self._str(data.get("outreach_email"), self._outreach_email(company, service_line, industry)),
            call_script=self._list(data.get("call_script"), self._call_script(company, industry)),
            recommendations=self._list(data.get("recommendations"), self._recommendations(domain, live_search_used, True)),
            confidence_score=confidence,
            notes=self._list(data.get("notes"), self._notes(sources, llm_used=True)),
            sources=sources,
            llm_used=True,
            live_search_used=live_search_used,
        )

    def _fallback_report(self, company: str, domain: str, service_line: str, manual_competitors: List[str], top_n: int, sources: List[SourceRecord], live_search_used: bool) -> IntelligenceReport:
        evidence = self._evidence_text(sources, 22000)
        industry, score = self.detector.detect(company, domain, service_line, evidence)
        confidence = self._confidence(sources, llm_used=False)
        if industry == "Not verified from collected public evidence":
            confidence = min(confidence, 55)
        competitors = self._competitor_insights(manual_competitors or self.detector.default_competitors(industry), industry, top_n)
        return IntelligenceReport(
            company=company,
            domain=domain,
            service_line=service_line,
            industry=industry,
            generated_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            overview=self._overview(company, domain, industry, evidence),
            detected_services=self._detected_services(industry, evidence),
            target_customers=self._target_customers(industry),
            positioning=self._positioning(company, industry),
            activity_signals=self._activity(sources),
            erp_report=self._erp_report(company, industry),
            crm_report=self._crm_report(company, industry),
            erp_modules=self.detector.erp_modules(industry),
            crm_modules=self.detector.crm_modules(industry),
            implementation_roadmap=self._roadmap(),
            competitors=competitors,
            swot=self._swot(company, industry),
            pestle=self._pestle(industry),
            market_gaps=self._market_gaps(company, industry),
            lead_opportunities=self._lead_opportunities(company, industry),
            outreach_email=self._outreach_email(company, service_line, industry),
            call_script=self._call_script(company, industry),
            recommendations=self._recommendations(domain, live_search_used, False),
            confidence_score=confidence,
            notes=self._notes(sources, llm_used=False),
            sources=sources,
            llm_used=False,
            live_search_used=live_search_used,
        )

    # --------------------------- Fallback sections ---------------------------
    def _overview(self, company: str, domain: str, industry: str, evidence: str) -> str:
        if evidence and len(evidence) > 350 and "Not verified" not in industry:
            return f"{company} is analyzed as a {industry} organization using the current input and collected public evidence from {domain or 'provided sources'}. The report focuses on ERP and CRM opportunities without reusing any fixed sample company data."
        return f"{company} has been analyzed using the current input. Some company facts are not verified from collected public evidence, so the report avoids unsupported claims and focuses on ERP/CRM process analysis."

    def _detected_services(self, industry: str, evidence: str) -> List[str]:
        mapping = {
            "Automobile / Automotive": ["Vehicle sales and dealer operations", "Service operations", "Spare parts and warranty support", "Customer inquiry and booking management"],
            "Professional Services / Consulting": ["Consulting/advisory services", "Client engagement management", "Proposal and account management", "Compliance/reporting workflows"],
            "Banking and Financial Services": ["Customer account services", "Loan and product inquiry handling", "Digital banking support", "Risk and compliance workflows"],
            "IT Services and Consulting": ["Technology consulting", "Application support", "Cloud/digital transformation", "Enterprise solution delivery"],
            "Fertilizer / Agriculture Cooperative": ["Fertilizer manufacturing and distribution", "Agri input and farmer support workflows", "Dealer/distributor management", "Plant, warehouse and supply chain operations", "Cooperative/member engagement"],
            "FMCG / Consumer Goods": ["Consumer goods manufacturing and distribution", "Dealer/distributor sales workflows", "Warehouse and inventory coordination", "Retail channel and consumer support", "Brand/campaign and complaint management"],
            "Building Materials / Cement": ["Cement/building material manufacturing and distribution", "Dealer and retailer order workflows", "Project sales and contractor engagement", "Dispatch, logistics and credit control", "Quality complaint and support management"],
            "Healthcare / Hospitals": ["Patient inquiry and appointment workflows", "Billing and pharmacy coordination", "Doctor/service scheduling", "Patient support"],
            "Food Delivery / Restaurant Tech": ["Food ordering and delivery workflows", "Restaurant partner onboarding", "Order tracking and support", "Campaigns, offers and customer retention", "Delivery and refund issue management"],
            "Hospitality / Restaurant": ["Restaurant reservation and order workflows", "Guest support", "Menu and billing operations", "Feedback and loyalty management"],
            "Engineering / Construction / EPC": ["Project execution", "Procurement and site operations", "Client proposal management", "Billing and progress tracking"],
        }
        return mapping.get(industry, ["Not verified from collected public evidence", "ERP/CRM process improvement focus"])

    def _target_customers(self, industry: str) -> List[str]:
        mapping = {
            "Automobile / Automotive": ["retail vehicle buyers", "dealers", "service customers", "fleet buyers"],
            "Professional Services / Consulting": ["enterprise clients", "CFO/CIO/COO teams", "compliance teams", "business transformation teams"],
            "Banking and Financial Services": ["retail customers", "MSME customers", "corporate clients", "loan applicants"],
            "IT Services and Consulting": ["enterprise clients", "IT departments", "digital transformation leaders", "support teams"],
            "Fertilizer / Agriculture Cooperative": ["farmers", "cooperative societies", "dealers/distributors", "plant operations teams", "field officers", "supply chain teams"],
            "FMCG / Consumer Goods": ["distributors", "dealers", "retailers", "sales teams", "warehouse teams", "consumer support teams", "brand managers"],
            "Building Materials / Cement": ["dealers", "retailers", "contractors", "builders", "project sales teams", "plant and logistics teams"],
            "Healthcare / Hospitals": ["patients", "doctors", "insurance desk", "hospital operations teams"],
            "Retail and Ecommerce": ["end customers", "store teams", "warehouse teams", "loyalty members"],
            "Food Delivery / Restaurant Tech": ["food ordering customers", "restaurant partners", "delivery partners", "support teams", "operations managers"],
            "Hospitality / Restaurant": ["guests", "restaurant customers", "hotel operations teams", "reservation teams"],
            "Engineering / Construction / EPC": ["government clients", "private developers", "project owners", "subcontractors"],
        }
        return mapping.get(industry, ["customers", "sales team", "operations team", "management team"])

    def _positioning(self, company: str, industry: str) -> str:
        if "Not verified" in industry:
            return "Market positioning is not verified from collected public evidence. Use API mode or official URLs for stronger validation."
        return f"{company} can be positioned in the {industry} segment, where ERP improves internal operations and CRM improves customer/client relationship workflows."

    def _erp_report(self, company: str, industry: str) -> List[str]:
        if industry == "Food Delivery / Restaurant Tech":
            return [
                f"ERP for {company} should connect restaurant partner master data, order operations, delivery partner workflows, finance settlement and refund reconciliation.",
                "Order lifecycle dashboards should track placed orders, accepted orders, preparation delays, delivery exceptions, cancellations and refunds.",
                "Finance workflows should support restaurant commission, partner payout, delivery cost, refund approval and reconciliation reporting.",
                "Operations users should get role-based access for city operations, partner support, customer support, finance and management reporting.",
            ]
        if industry == "Fertilizer / Agriculture Cooperative":
            return [
                f"ERP for {company} should integrate plant production planning, raw material procurement, fertilizer batch/quality tracking, warehouse stock, dealer dispatch and finance/compliance reporting.",
                "Distribution dashboards should track plant-wise production, bagging, rake/truck dispatches, dealer allocation, pending indents, stock ageing and regional demand.",
                "Finance workflows should support purchase, freight, subsidy/compliance documentation, dealer billing, credit control and reconciliation.",
                "Role-based access should separate plant operations, procurement, quality, logistics, finance, cooperative/member services and management reporting.",
            ]
        if industry == "Building Materials / Cement":
            return [
                f"ERP for {company} should connect plant production, clinker/cement quality, warehouse stock, dealer allocation, project sales orders, dispatch planning and finance collection workflows.",
                "Dispatch dashboards should track plant-wise availability, dealer indents, truck/rake dispatches, freight cost, delivery status, stock ageing and regional demand.",
                "Finance workflows should support dealer credit limits, project customer billing, schemes/discounts, tax invoices, collections and reconciliation.",
                "Role-based access should separate plant, quality, logistics, dealer sales, project sales, finance, support and management reporting users.",
            ]
        return [
            f"ERP for {company} should centralize master data, finance, approvals, operational workflows and management reporting.",
            f"For {industry}, ERP modules should reduce manual follow-up, duplicate data entry and delayed reporting.",
            "Dashboards should track pending approvals, operational bottlenecks, billing status, collections and team productivity.",
            "Role-based access should separate sales, operations, finance, support and management responsibilities.",
        ]

    def _crm_report(self, company: str, industry: str) -> List[str]:
        if industry == "Food Delivery / Restaurant Tech":
            return [
                f"CRM for {company} should manage customer issues, restaurant partner communication, campaign targeting, order feedback, refund follow-ups and retention journeys.",
                "Customer 360 should show order history, complaints, refunds, ratings, offers used and support interactions in one view.",
                "Restaurant partner CRM should track onboarding, menu updates, order complaints, settlement queries, training/support status and account health.",
                "Campaign automation should segment users by location, cuisine preference, order frequency, churn risk and offer response.",
            ]
        if industry == "Fertilizer / Agriculture Cooperative":
            return [
                f"CRM for {company} should manage farmer inquiries, dealer/distributor communication, field officer visits, crop advisory campaigns, complaint tickets and cooperative/member engagement.",
                "Farmer 360 should show crop/location profile, product interest, complaints, campaign responses, advisory history and support interactions.",
                "Dealer CRM should track orders/indents, stock issues, dispatch updates, credit follow-up, scheme communication and service tickets.",
                "Campaign automation should support season-wise fertilizer awareness, agronomy advisory, dealer engagement and quality complaint follow-up.",
            ]
        if industry == "Building Materials / Cement":
            return [
                f"CRM for {company} should manage dealer inquiries, project sales leads, contractor/builder engagement, quotation follow-ups, complaints, delivery updates and loyalty communication.",
                "Customer 360 should show dealer order history, outstanding payments, schemes, complaints, dispatch issues and sales opportunities.",
                "Project CRM should track builder/contractor leads, site visits, quotation stages, product approvals, order conversion and delivery coordination.",
                "Campaign automation should support dealer schemes, contractor meets, regional demand campaigns and quality complaint follow-up.",
            ]
        return [
            f"CRM for {company} should capture every inquiry, contact, opportunity, follow-up, proposal and customer interaction.",
            f"For {industry}, CRM should improve lead conversion, account visibility, reminders, service tracking and customer communication.",
            "Pipeline dashboards should show hot leads, overdue follow-ups, lost reasons, conversion rates and next actions.",
            "Email/WhatsApp/SMS integration can automate reminders, appointment updates and customer communication.",
        ]

    def _roadmap(self) -> List[str]:
        return [
            "Step 1: Confirm official company source data, domain, business units and report scope.",
            "Step 2: Map existing sales, operations, finance, support and reporting workflows.",
            "Step 3: Identify pain points such as manual entry, delayed follow-up, weak visibility and duplicate records.",
            "Step 4: Design ERP modules, CRM modules, user roles, approval flows and dashboards.",
            "Step 5: Implement pilot with sample data, validate reports, train users and roll out phase-wise.",
            "Step 6: Add integrations such as payment gateway, email, WhatsApp, APIs, BI dashboard and analytics.",
        ]

    def _swot(self, company: str, industry: str) -> Dict[str, List[str]]:
        return {
            "Strengths": [f"{company} has clear scope for structured ERP/CRM process mapping.", "ERP and CRM can create a single source of truth for operations and customer data."],
            "Weaknesses": ["Some facts may require official source validation.", "Existing manual workflows may create duplicate data and reporting delays."],
            "Opportunities": ["Automated follow-ups, dashboards and workflow approvals can improve productivity.", f"Industry-specific ERP/CRM modules can improve visibility for {industry}."],
            "Threats": ["Competitors with better digital processes may respond faster to customers.", "Poor data quality can reduce report accuracy and decision confidence."],
        }

    def _pestle(self, industry: str) -> Dict[str, str]:
        return {
            "Political": "Government policies, sector regulations and procurement rules can affect business workflows.",
            "Economic": "Budget cycles, customer demand and cost pressure influence ERP/CRM investment decisions.",
            "Social": "Customers expect faster response, transparent communication and personalized service.",
            "Technological": "Cloud ERP, CRM, analytics, AI and automation can improve decision-making and operational speed.",
            "Legal": "Data privacy, contracts, audit trails and compliance approvals must be controlled.",
            "Environmental": "Digital workflows can reduce paperwork and improve sustainability reporting.",
        }

    def _market_gaps(self, company: str, industry: str) -> List[str]:
        return [
            "Manual follow-up and disconnected spreadsheets can delay response time.",
            "ERP and CRM data often remain separate, reducing management visibility.",
            "Customer/support history may not be available in one unified dashboard.",
            "Industry-specific reports are needed for faster sales and operations decisions.",
        ]

    def _lead_opportunities(self, company: str, industry: str) -> List[str]:
        return [
            f"Pitch an ERP + CRM discovery workshop for {company} focused on {industry} workflows.",
            "Offer dashboard prototype covering leads, operations, billing, follow-ups and pending tasks.",
            "Suggest integration with website forms, WhatsApp/email communication and payment/reporting workflows.",
            "Create department-wise roadmap for sales, operations, finance and management users.",
        ]

    def _outreach_email(self, company: str, service_line: str, industry: str) -> str:
        return (
            f"Subject: ERP and CRM process improvement opportunity for {company}\n\n"
            f"Hello Team,\n\nWe analyzed {company} from an ERP and CRM business process perspective. "
            f"For the {industry} context, there may be opportunities to improve lead tracking, customer communication, operational visibility, approvals, billing and management dashboards.\n\n"
            f"We can share a short discovery roadmap for {service_line} and show how an integrated ERP + CRM workflow can reduce manual follow-ups and improve reporting.\n\n"
            "Regards,\nBusiness Intelligence Team"
        )

    def _call_script(self, company: str, industry: str) -> List[str]:
        return [
            f"Opening: We are studying ERP and CRM process improvement for {company} in the {industry} segment.",
            "Question 1: How are customer inquiries, follow-ups and service requests currently tracked?",
            "Question 2: Are operations, finance, billing and customer communication connected in one system?",
            "Question 3: Which reports take the most manual effort today?",
            "Close: We can share a short ERP + CRM roadmap and dashboard sample for your workflow.",
        ]

    def _recommendations(self, domain: str, live_search_used: bool, llm_used: bool) -> List[str]:
        items = [
            "Use the current UI input as the primary company context. Old sample values are never reused.",
            "Do not treat the ERP/CRM report focus as the company's own service unless official evidence supports it.",
        ]
        if not domain:
            items.append("Add the official domain for better company verification.")
        if not live_search_used:
            items.append("For real company data from server/search, turn Live Search ON and provide a Serper or Tavily API key.")
        if not llm_used:
            items.append("For MNC-level factual synthesis, enable OpenAI LLM synthesis with an OpenAI API key.")
        items.append("Add official About, Services, Products or Investor pages in Public URLs for highest accuracy.")
        return items

    def _notes(self, sources: List[SourceRecord], llm_used: bool) -> List[str]:
        notes = ["Report generated from current user input and collected source records only."]
        if llm_used:
            notes.append("OpenAI synthesis was used after source collection.")
        else:
            notes.append("Fallback rule-based analysis was used because OpenAI synthesis was not enabled or failed.")
        if any(s.source_type == "live_search" and s.status in {"not_run", "error"} for s in sources):
            notes.append("Live search did not run successfully. Add a valid API key for stronger real-time data.")
        return notes

    # --------------------------- Utilities ---------------------------
    def _competitors_from_json(self, value: Any, manual: List[str], industry: str, top_n: int) -> List[CompetitorInsight]:
        competitors: List[CompetitorInsight] = []
        for item in value if isinstance(value, list) else []:
            if not isinstance(item, dict):
                continue
            name = self._str(item.get("name"), "").strip()
            if not name or re.match(r"https?://|www\.", name, re.I):
                continue
            competitors.append(
                CompetitorInsight(
                    name=name,
                    fit_score=self._int_between(item.get("fit_score"), 0, 100, 75),
                    focus=self._str(item.get("focus"), f"Comparable {industry} competitor."),
                    strengths=self._list(item.get("strengths"), ["Known market presence"]),
                    risks=self._list(item.get("risks"), ["May have stronger digital process maturity"]),
                    differentiation=self._str(item.get("differentiation"), "Differentiate through industry-specific ERP + CRM roadmap."),
                    suggested_action=self._str(item.get("suggested_action"), "Compare services, customer segments and process gaps."),
                )
            )
        if not competitors:
            competitors = self._competitor_insights(manual or self.detector.default_competitors(industry), industry, top_n)
        return competitors[:top_n]

    def _competitor_insights(self, names: List[str], industry: str, top_n: int) -> List[CompetitorInsight]:
        names = [n for n in unique_keep_order(names) if n and not re.match(r"https?://|www\.", n.strip(), re.I)]
        if not names:
            names = self.detector.default_competitors(industry)
        out: List[CompetitorInsight] = []
        for idx, name in enumerate(names[:top_n]):
            out.append(
                CompetitorInsight(
                    name=name,
                    fit_score=max(58, 90 - idx * 5),
                    focus=f"Comparable player in {industry} or related business process segment.",
                    strengths=["Known market/category presence", "Can influence customer expectations and pricing benchmarks"],
                    risks=["May already offer stronger digital workflows", "May have better customer communication and reporting"],
                    differentiation="Differentiate with evidence-based ERP + CRM workflow mapping, dashboard prototype and fast implementation roadmap.",
                    suggested_action="Study official services, customer segments, digital channels and process automation gaps.",
                )
            )
        return out

    def _activity(self, sources: List[SourceRecord]) -> List[str]:
        available = [s for s in sources if s.status == "available"]
        if not available:
            return ["No live public source was verified. Add official URLs or API keys for source-backed activity signals."]
        return [f"Source available: {s.title[:90]} ({s.source_type})" for s in available[:5]]

    def _confidence(self, sources: List[SourceRecord], llm_used: bool) -> int:
        score = 45
        if any(s.source_type == "official_domain" and s.status == "available" for s in sources):
            score += 20
        if any(s.source_type == "user_url" and s.status == "available" for s in sources):
            score += 15
        if any(s.source_type == "live_search" and s.status == "available" for s in sources):
            score += 15
        if llm_used:
            score += 10
        return max(10, min(100, score))

    def _evidence_text(self, sources: List[SourceRecord], max_chars: int) -> str:
        parts: List[str] = []
        for idx, src in enumerate(sorted(sources, key=lambda s: s.quality_score, reverse=True), start=1):
            parts.append(f"SOURCE {idx}: {src.title}\nURL: {src.url}\nTYPE: {src.source_type}\nSTATUS: {src.status}\nNOTE: {src.note}\nCONTENT: {src.content[:5000]}")
        return clean_text("\n\n".join(parts), max_chars)

    def _str(self, value: Any, default: str) -> str:
        text = str(value).strip() if value is not None else ""
        return text or default

    def _list(self, value: Any, default: List[str]) -> List[str]:
        if isinstance(value, list):
            out = [str(v).strip() for v in value if str(v).strip()]
            return out or default
        if isinstance(value, str) and value.strip():
            return split_csv(value) or [value.strip()]
        return default

    def _int_between(self, value: Any, lo: int, hi: int, default: int) -> int:
        try:
            n = int(float(value))
        except Exception:
            n = default
        return max(lo, min(hi, n))
