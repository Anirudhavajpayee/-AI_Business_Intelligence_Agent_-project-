from __future__ import annotations

from pathlib import Path
import os
import sys

os.environ["BI_SKIP_NETWORK"] = "1"

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from agent.analyzer import BusinessIntelligenceEngine
from agent.utils import parse_quick_input, split_names_and_urls


def test_quick_parser_multiline_service():
    text = """Company: Maruti Suzuki India
Domain: marutisuzuki.com
Service: ERP and CRM Business Process Analysis for Automobile Manufacturing, Dealer Management,
Sales, Service Operations, Spare Parts Inventory, Customer Relationship and Warranty Management
Competitors: Hyundai Motor India, Tata Motors, Mahindra & Mahindra
URLs: https://www.marutisuzuki.com/corporate/about-us
"""
    data = parse_quick_input(text)
    assert data["company"] == "Maruti Suzuki India"
    assert data["domain"] == "marutisuzuki.com"
    assert "Automobile Manufacturing" in data["service_line"]
    assert "Sales, Service Operations" in data["service_line"]
    assert "Hyundai" in data["competitors"]
    assert "marutisuzuki" in data["urls"]


def test_urls_not_competitors():
    names, urls = split_names_and_urls("Tata Motors, https://www.marutisuzuki.com/corporate/about-us, Honda Cars India")
    assert names == ["Tata Motors", "Honda Cars India"]
    assert len(urls) == 1


def test_offline_dynamic_industry_cases():
    engine = BusinessIntelligenceEngine()
    cases = [
        ("Maruti Suzuki India", "marutisuzuki.com", "Automobile"),
        ("PWC", "pwc.com", "Professional"),
        ("Tata Consultancy Services", "tcs.com", "IT Services"),
        ("HDFC Bank", "hdfc.bank.in", "Banking"),
        ("Apollo Hospitals", "apollohospitals.com", "Healthcare"),
        ("Larsen & Toubro", "larsentoubro.com", "Engineering"),
        ("Asian Paints", "asianpaints.com", "Paints"),
        ("RSPL Group", "rsplgroup.com", "FMCG"),
    ]
    for company, domain, expected in cases:
        report = engine.analyze(company=company, domain=domain, use_live_search=False, top_n=5)
        assert expected.lower() in report.industry.lower(), f"{company} -> {report.industry}"
        assert report.company == company
        assert "Snow Fountain" not in report.overview
        assert report.competitors


def test_unknown_company_does_not_fake_facts():
    report = BusinessIntelligenceEngine().analyze(company="New Local Company XYZ", domain="", use_live_search=False)
    assert report.company == "New Local Company XYZ"
    assert report.confidence_score <= 60
    assert "sample" not in report.overview.lower()


if __name__ == "__main__":
    test_quick_parser_multiline_service()
    test_urls_not_competitors()
    test_offline_dynamic_industry_cases()
    test_unknown_company_does_not_fake_facts()
    print("ALL TESTS PASSED")


def test_zomato_food_delivery_detection():
    from agent.analyzer import BusinessIntelligenceEngine
    report = BusinessIntelligenceEngine().analyze(
        company="Zomato",
        domain="zomato.com",
        service_line="ERP and CRM Business Process Analysis for Food Delivery, Restaurant Partner Management, Order Management, Customer Support, Delivery Operations and Marketing Automation",
        manual_competitors=["Swiggy", "EatSure", "Domino's India", "Magicpin", "ONDC Food"],
        urls=["https://www.zomato.com/"],
        top_n=5,
    )
    assert report.industry == "Food Delivery / Restaurant Tech"
    assert any("Restaurant Partner" in m or "Order Management" in m for m in report.erp_modules)
    assert any("Restaurant Partner" in m or "Order Issue" in m for m in report.crm_modules)

def test_cisco_networking_security_detection():
    from agent.analyzer import BusinessIntelligenceEngine
    report = BusinessIntelligenceEngine().analyze(
        company="Cisco Systems (India) Private Limited",
        domain="cisco.com",
        service_line="ERP and CRM Business Process Analysis for Enterprise Networking, Cybersecurity, Collaboration, Data Center, Cloud, Partner Sales, Customer Support and Subscription Lifecycle Management",
        manual_competitors=["Juniper Networks", "HPE Aruba Networking", "Fortinet", "Palo Alto Networks", "Check Point"],
        urls=["https://www.cisco.com/site/in/en/products/index.html"],
        top_n=5,
    )
    assert "Networking" in report.industry or "Cybersecurity" in report.industry
    assert any("Subscription" in m or "Licensing" in m for m in report.erp_modules)
    assert any("Partner" in m or "Customer Success" in m for m in report.crm_modules)


def test_building_material_cement_detection_does_not_become_automobile():
    report = BusinessIntelligenceEngine().analyze(
        company="UltraTech Cement",
        domain="ultratechcement.com",
        service_line="ERP and CRM Business Process Analysis for Cement Manufacturing, Dealer Management, Logistics, Sales Distribution, Project Sales, Inventory and Customer Support",
        manual_competitors=["Ambuja Cements", "ACC", "Shree Cement", "Dalmia Bharat", "JK Cement"],
        urls=["https://www.ultratechcement.com/"],
        top_n=5,
    )
    assert report.industry == "Building Materials / Cement"
    assert report.industry != "Automobile / Automotive"
    assert any("Dealer" in m or "Project" in m for m in report.crm_modules)


def test_wipro_iffco_kribhco_rspl_detection_cases():
    cases = [
        ("Wipro", "wipro.com", "ERP and CRM Business Process Analysis for IT Services, Consulting, Cloud Transformation and Enterprise Application Management", "IT Services and Consulting"),
        ("IFFCO", "iffco.in", "ERP and CRM Business Process Analysis for Fertilizer Manufacturing, Farmer Support, Dealer Distribution and Supply Chain", "Fertilizer / Agriculture Cooperative"),
        ("KRIBHCO", "kribhco.net", "ERP and CRM Business Process Analysis for Fertilizer Manufacturing, Cooperative Operations, Dealer Distribution and Farmer Support", "Fertilizer / Agriculture Cooperative"),
        ("RSPL Group", "rsplgroup.com", "ERP and CRM Business Process Analysis for FMCG Manufacturing, Household Products, Dairy, Footwear, Sales Distribution and Dealer Management", "FMCG / Consumer Goods"),
    ]
    for company, domain, focus, expected in cases:
        report = BusinessIntelligenceEngine().analyze(company=company, domain=domain, service_line=focus)
        assert report.industry == expected
